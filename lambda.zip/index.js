exports.handler = (event, context) => {
	var mysql = require('mysql');
	var connection = mysql.createConnection({
		host	 : 'ec2-3-91-55-20.compute-1.amazonaws.com', 
		user	 : 'root', 
		password : 'qwe123', 
		port     : '3306',
		database : 'urop'
	});
	connection.connect();
    console.log('Received event:');
	console.log(JSON.stringify(event, null, '  '));
    
    connection.query("insert into data VALUES (?,?,?,?,?,now(),?,?);",[event.d_id,event.temp,event.humid,event.pm2_5,event.pm10,event.latit,event.longit], function(err, rows, fields) {
        console.log("rows: " + rows);
        context.succeed('Success');
    });
	connection.end();
};

